/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Just4RIR/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[41];
    char stringdata0[1110];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 24), // "on_bouton_rayons_clicked"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 24), // "on_bouton_source_clicked"
QT_MOC_LITERAL(4, 62, 26), // "on_bouton_listener_clicked"
QT_MOC_LITERAL(5, 89, 32), // "on_spinBox_nbRebond_valueChanged"
QT_MOC_LITERAL(6, 122, 4), // "arg1"
QT_MOC_LITERAL(7, 127, 35), // "on_spinBox_attenuation_valueC..."
QT_MOC_LITERAL(8, 163, 31), // "on_bouton_sourcesImages_clicked"
QT_MOC_LITERAL(9, 195, 21), // "on_bouton_RIR_clicked"
QT_MOC_LITERAL(10, 217, 27), // "on_checkBox_rayAuto_toggled"
QT_MOC_LITERAL(11, 245, 7), // "checked"
QT_MOC_LITERAL(12, 253, 27), // "on_bouton_audioFile_clicked"
QT_MOC_LITERAL(13, 281, 25), // "on_bouton_ecouter_clicked"
QT_MOC_LITERAL(14, 307, 27), // "on_AudioSlider_valueChanged"
QT_MOC_LITERAL(15, 335, 5), // "value"
QT_MOC_LITERAL(16, 341, 18), // "on_positionChanged"
QT_MOC_LITERAL(17, 360, 8), // "position"
QT_MOC_LITERAL(18, 369, 18), // "on_durationChanged"
QT_MOC_LITERAL(19, 388, 36), // "on_spinBox_freqEchan_editingF..."
QT_MOC_LITERAL(20, 425, 37), // "on_spinBox_seuilArret_editing..."
QT_MOC_LITERAL(21, 463, 29), // "on_bouton_convolution_clicked"
QT_MOC_LITERAL(22, 493, 28), // "on_bouton_projection_clicked"
QT_MOC_LITERAL(23, 522, 25), // "on_bouton_saveRir_clicked"
QT_MOC_LITERAL(24, 548, 25), // "on_bouton_diffRir_clicked"
QT_MOC_LITERAL(25, 574, 22), // "on_bouton_data_clicked"
QT_MOC_LITERAL(26, 597, 31), // "on_spinBox_gain_editingFinished"
QT_MOC_LITERAL(27, 629, 38), // "on_spinBox_numListener_editin..."
QT_MOC_LITERAL(28, 668, 32), // "on_spinBox_nbRay_editingFinished"
QT_MOC_LITERAL(29, 701, 38), // "on_doubleSpinBox_siTps_editin..."
QT_MOC_LITERAL(30, 740, 45), // "on_doubleSpinBox_siTps_erreur..."
QT_MOC_LITERAL(31, 786, 36), // "on_spinBox_numSource_editingF..."
QT_MOC_LITERAL(32, 823, 23), // "on_actionInfo_triggered"
QT_MOC_LITERAL(33, 847, 30), // "on_radioButton_rebFixe_clicked"
QT_MOC_LITERAL(34, 878, 30), // "on_radioButton_seuildB_clicked"
QT_MOC_LITERAL(35, 909, 32), // "on_radioButton_Fibonacci_clicked"
QT_MOC_LITERAL(36, 942, 35), // "on_radioButton_vertexSource_c..."
QT_MOC_LITERAL(37, 978, 35), // "on_spinBox_temperature_valueC..."
QT_MOC_LITERAL(38, 1014, 32), // "on_spinBox_humidite_valueChanged"
QT_MOC_LITERAL(39, 1047, 28), // "on_radioButton_tpsSI_clicked"
QT_MOC_LITERAL(40, 1076, 33) // "on_radioButton_initSource_cli..."

    },
    "MainWindow\0on_bouton_rayons_clicked\0"
    "\0on_bouton_source_clicked\0"
    "on_bouton_listener_clicked\0"
    "on_spinBox_nbRebond_valueChanged\0arg1\0"
    "on_spinBox_attenuation_valueChanged\0"
    "on_bouton_sourcesImages_clicked\0"
    "on_bouton_RIR_clicked\0on_checkBox_rayAuto_toggled\0"
    "checked\0on_bouton_audioFile_clicked\0"
    "on_bouton_ecouter_clicked\0"
    "on_AudioSlider_valueChanged\0value\0"
    "on_positionChanged\0position\0"
    "on_durationChanged\0"
    "on_spinBox_freqEchan_editingFinished\0"
    "on_spinBox_seuilArret_editingFinished\0"
    "on_bouton_convolution_clicked\0"
    "on_bouton_projection_clicked\0"
    "on_bouton_saveRir_clicked\0"
    "on_bouton_diffRir_clicked\0"
    "on_bouton_data_clicked\0"
    "on_spinBox_gain_editingFinished\0"
    "on_spinBox_numListener_editingFinished\0"
    "on_spinBox_nbRay_editingFinished\0"
    "on_doubleSpinBox_siTps_editingFinished\0"
    "on_doubleSpinBox_siTps_erreur_editingFinished\0"
    "on_spinBox_numSource_editingFinished\0"
    "on_actionInfo_triggered\0"
    "on_radioButton_rebFixe_clicked\0"
    "on_radioButton_seuildB_clicked\0"
    "on_radioButton_Fibonacci_clicked\0"
    "on_radioButton_vertexSource_clicked\0"
    "on_spinBox_temperature_valueChanged\0"
    "on_spinBox_humidite_valueChanged\0"
    "on_radioButton_tpsSI_clicked\0"
    "on_radioButton_initSource_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      35,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  189,    2, 0x08 /* Private */,
       3,    0,  190,    2, 0x08 /* Private */,
       4,    0,  191,    2, 0x08 /* Private */,
       5,    1,  192,    2, 0x08 /* Private */,
       7,    1,  195,    2, 0x08 /* Private */,
       8,    0,  198,    2, 0x08 /* Private */,
       9,    0,  199,    2, 0x08 /* Private */,
      10,    1,  200,    2, 0x08 /* Private */,
      12,    0,  203,    2, 0x08 /* Private */,
      13,    0,  204,    2, 0x08 /* Private */,
      14,    1,  205,    2, 0x08 /* Private */,
      16,    1,  208,    2, 0x08 /* Private */,
      18,    1,  211,    2, 0x08 /* Private */,
      19,    0,  214,    2, 0x08 /* Private */,
      20,    0,  215,    2, 0x08 /* Private */,
      21,    0,  216,    2, 0x08 /* Private */,
      22,    0,  217,    2, 0x08 /* Private */,
      23,    0,  218,    2, 0x08 /* Private */,
      24,    0,  219,    2, 0x08 /* Private */,
      25,    0,  220,    2, 0x08 /* Private */,
      26,    0,  221,    2, 0x08 /* Private */,
      27,    0,  222,    2, 0x08 /* Private */,
      28,    0,  223,    2, 0x08 /* Private */,
      29,    0,  224,    2, 0x08 /* Private */,
      30,    0,  225,    2, 0x08 /* Private */,
      31,    0,  226,    2, 0x08 /* Private */,
      32,    0,  227,    2, 0x08 /* Private */,
      33,    0,  228,    2, 0x08 /* Private */,
      34,    0,  229,    2, 0x08 /* Private */,
      35,    0,  230,    2, 0x08 /* Private */,
      36,    0,  231,    2, 0x08 /* Private */,
      37,    1,  232,    2, 0x08 /* Private */,
      38,    1,  235,    2, 0x08 /* Private */,
      39,    0,  238,    2, 0x08 /* Private */,
      40,    0,  239,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::LongLong,   17,
    QMetaType::Void, QMetaType::LongLong,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_bouton_rayons_clicked(); break;
        case 1: _t->on_bouton_source_clicked(); break;
        case 2: _t->on_bouton_listener_clicked(); break;
        case 3: _t->on_spinBox_nbRebond_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_spinBox_attenuation_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_bouton_sourcesImages_clicked(); break;
        case 6: _t->on_bouton_RIR_clicked(); break;
        case 7: _t->on_checkBox_rayAuto_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->on_bouton_audioFile_clicked(); break;
        case 9: _t->on_bouton_ecouter_clicked(); break;
        case 10: _t->on_AudioSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_positionChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 12: _t->on_durationChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 13: _t->on_spinBox_freqEchan_editingFinished(); break;
        case 14: _t->on_spinBox_seuilArret_editingFinished(); break;
        case 15: _t->on_bouton_convolution_clicked(); break;
        case 16: _t->on_bouton_projection_clicked(); break;
        case 17: _t->on_bouton_saveRir_clicked(); break;
        case 18: _t->on_bouton_diffRir_clicked(); break;
        case 19: _t->on_bouton_data_clicked(); break;
        case 20: _t->on_spinBox_gain_editingFinished(); break;
        case 21: _t->on_spinBox_numListener_editingFinished(); break;
        case 22: _t->on_spinBox_nbRay_editingFinished(); break;
        case 23: _t->on_doubleSpinBox_siTps_editingFinished(); break;
        case 24: _t->on_doubleSpinBox_siTps_erreur_editingFinished(); break;
        case 25: _t->on_spinBox_numSource_editingFinished(); break;
        case 26: _t->on_actionInfo_triggered(); break;
        case 27: _t->on_radioButton_rebFixe_clicked(); break;
        case 28: _t->on_radioButton_seuildB_clicked(); break;
        case 29: _t->on_radioButton_Fibonacci_clicked(); break;
        case 30: _t->on_radioButton_vertexSource_clicked(); break;
        case 31: _t->on_spinBox_temperature_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 32: _t->on_spinBox_humidite_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->on_radioButton_tpsSI_clicked(); break;
        case 34: _t->on_radioButton_initSource_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 35)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 35;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 35)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 35;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
